import React from 'react'

function AmendmentHistory() {
  return (
    <div>AmendmentHistory</div>
  )
}

export default AmendmentHistory