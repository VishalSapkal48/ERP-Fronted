import React from 'react'

function QuotationManager() {
  return (
    <div>QuotationManager</div>
  )
}

export default QuotationManager