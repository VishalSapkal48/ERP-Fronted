import React from "react";

const ProjectYewale = () => {
  return (
    <div className="p-8">
      <h2 className="text-xl font-bold">Yewale Project</h2>
      <p className="mt-4 text-gray-600">Details of Yewale project go here.</p>
    </div>
  );
};

export default ProjectYewale;
