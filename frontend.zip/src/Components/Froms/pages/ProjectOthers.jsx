import React from "react";

const ProjectOthers = () => {
  return (
    <div className="p-8">
      <h2 className="text-xl font-bold">Other Projects</h2>
      <p className="mt-4 text-gray-600">Details of other projects go here.</p>
    </div>
  );
};

export default ProjectOthers;
