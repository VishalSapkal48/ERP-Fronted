import React from "react";

const ProjectNadbramha = () => {
  return (
    <div className="p-8">
      <h2 className="text-xl font-bold">Nadbramha Project</h2>
      <p className="mt-4 text-gray-600">
        Details of Nadbramha project go here.
      </p>
    </div>
  );
};

export default ProjectNadbramha;
