import React from 'react'

function AdminDashBoard() {
  return (
    <div>AdminDashBoard</div>
  )
}

export default AdminDashBoard;